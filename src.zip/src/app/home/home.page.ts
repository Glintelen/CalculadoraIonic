import { Component } from '@angular/core';
import { AlertButton, AlertController } from '@ionic/angular';


@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {  
  public alertButtons = ['OK'];
  isAlertOpen = false;
  setOpen(isOpen: boolean) {
    this.isAlertOpen = isOpen;
  }
  constructor(public alertCtrl: AlertController){}
  n1:any;
  n2:any;
  n3:any;
  a: any;  


  calcular(){
    
  switch(this.a){
    case 'soma':
    console.log(this.n3=this.n1+this.n2);
    break;
    case 'subtrac':
    console.log(this.n3=this.n1-this.n2);
    break;
    case 'multiplic':
    console.log(this.n3=this.n1*this.n2);
    break;
    case 'divisao':
      if(this.n2!=0){console.log(this.n3=this.n1/this.n2);}
      else{this.setOpen(true);}
      break;
      
    }
    
    
  }
  
}
